"""
GSM8K math evaluation script.

- Use DeepSeek API to evaluate model answers on GSM8K math problems.
- Judge correctness of model answers.
- Batch process multiple test_result.xlsx files.
- Output accuracy and average character count.

Usage:
- Run: process all test_result.xlsx under result/gsm8k
- --file <path>: specific file
- --limit <num>: limit rows per file

Output: *_evaluated.xlsx; terminal summary.
"""

import asyncio
import aiohttp
import json
import os
import pandas as pd
from dotenv import load_dotenv
import glob
import re
import tqdm
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

load_dotenv()

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)

API_KEY = os.getenv("DEEPSEEK_API_KEY")
BASE_URL = "https://api.deepseek.com/chat/completions"
TEMPLATE_FILE = os.path.join(SCRIPT_DIR, 'gsm8k.md')
GSM8K_RESULT_DIR = os.path.join(PROJECT_ROOT, 'result', 'gsm8k')

def estimate_tokens(text):
    """Character count (aligned with baseline)."""
    if not isinstance(text, str):
        return 0
    return len(text)

async def get_evaluation(session, index, user_prompt, model_response, template_content, semaphore):
    """Call DeepSeek API; return (index, data)."""
    full_prompt = template_content.replace("{{user_prompt}}", str(user_prompt))\
                                  .replace("{{model_response}}", str(model_response))
    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": "You are an expert math teacher and evaluator."},
            {"role": "user", "content": full_prompt}
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.0,
        "max_tokens": 1024
    }
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    try:
        async with semaphore:
            for attempt in range(3):
                try:
                    async with session.post(BASE_URL, json=payload, headers=headers, timeout=60) as resp:
                        if resp.status == 200:
                            result = await resp.json()
                            content_str = result['choices'][0]['message']['content']
                            try:
                                content_str = content_str.replace("```json", "").replace("```", "").strip()
                                try:
                                    data = json.loads(content_str)
                                except json.JSONDecodeError:
                                    reasoning_match = re.search(r'"reasoning":\s*"(.*?)"', content_str, re.DOTALL)
                                    is_correct_match = re.search(r'"is_correct":\s*(true|false)', content_str, re.IGNORECASE)
                                    ground_truth_match = re.search(r'"ground_truth":\s*"(.*?)"', content_str, re.DOTALL)
                                    if reasoning_match and is_correct_match:
                                        data = {
                                            "reasoning": reasoning_match.group(1),
                                            "is_correct": is_correct_match.group(1).lower() == 'true',
                                            "ground_truth": ground_truth_match.group(1) if ground_truth_match else ""
                                        }
                                    else:
                                        print(f"[Row {index}] JSON parse and regex extraction failed: {content_str}", flush=True)
                                        return index, None
                                return index, data
                            except Exception as e:
                                print(f"[Row {index}] Parse failed: {content_str}")
                                return index, None
                        else:
                            print(f"[Row {index}] API error: {resp.status}, retrying ({attempt+1}/3)")
                            await asyncio.sleep(2)
                except Exception as e:
                    print(f"[Row {index}] Request error: {e}, retrying ({attempt+1}/3)")
                    await asyncio.sleep(2)
            print(f"[Row {index}] Max retries reached, evaluation failed")
            return index, None
    except Exception as e:
        print(f"[Row {index}] Uncaught exception: {e}")
        return index, None

async def process_file(file_path, template_content, limit=None):
    """Process a single Excel file."""
    print(f"Processing file: {file_path}", flush=True)
    try:
        df = pd.read_excel(file_path)
        if limit:
            df = df.head(limit)
    except Exception as e:
        print(f"Failed to read Excel {file_path}: {e}")
        return None
    semaphore = asyncio.Semaphore(15)
    tasks = []
    token_counts = []
    async with aiohttp.ClientSession() as session:
        for index, row in df.iterrows():
            user_prompt = row.get('prompt', '')
            model_response = row.get('response', '')
            token_counts.append(estimate_tokens(str(model_response)))
            task = get_evaluation(session, index, user_prompt, model_response, template_content, semaphore)
            tasks.append(task)
        print(f"Evaluating {len(tasks)} rows...", flush=True)
        results_list = []
        for f in tqdm.tqdm(asyncio.as_completed(tasks), total=len(tasks)):
            result = await f
            results_list.append(result)
        results_list.sort(key=lambda x: x[0])
        results = [r[1] for r in results_list]
    df['judge_reasoning'] = None
    df['judge_ground_truth'] = None
    df['judge_is_correct'] = None
    df['estimated_tokens'] = token_counts
    success_count = 0
    valid_results = 0
    for i, res in enumerate(results):
        if res:
            valid_results += 1
            df.at[i, 'judge_reasoning'] = res.get('reasoning', '')
            df.at[i, 'judge_ground_truth'] = res.get('ground_truth', '')
            is_correct = res.get('is_correct', False)
            df.at[i, 'judge_is_correct'] = is_correct
            if is_correct:
                success_count += 1
    acc = success_count / len(df) if len(df) > 0 else 0
    avg_tokens = sum(token_counts) / len(token_counts) if len(token_counts) > 0 else 0
    output_file = file_path.replace('.xlsx', '_evaluated.xlsx')

    def clean_illegal_chars(val):
        if isinstance(val, str):
            return ILLEGAL_CHARACTERS_RE.sub('', val)
        return val
    df = df.applymap(clean_illegal_chars)

    try:
        df.to_excel(output_file, index=False)
        print(f"Results saved to: {output_file}", flush=True)
    except Exception as e:
        print(f"Failed to save Excel: {e}", flush=True)
        backup_csv = output_file.replace('.xlsx', '.csv')
        try:
            df.to_csv(backup_csv, index=False, encoding='utf-8-sig')
            print(f"Saved as CSV backup: {backup_csv}", flush=True)
        except Exception as e2:
            print(f"CSV backup also failed: {e2}", flush=True)
    return {
        "file": os.path.basename(os.path.dirname(file_path)) + "/" + os.path.basename(file_path),
        "acc": acc,
        "avg_tokens": avg_tokens,
        "total": len(df),
        "success": success_count
    }

def load_existing_evaluated_results(base_dir):
    """Load all existing *_evaluated.xlsx results; return list in same format as process_file."""
    results = []
    search_pattern = os.path.join(base_dir, '**', '*_evaluated.xlsx')
    evaluated_files = glob.glob(search_pattern, recursive=True)
    for evaluated_file in evaluated_files:
        try:
            df = pd.read_excel(evaluated_file)
            if 'judge_is_correct' in df.columns:
                success_count = df['judge_is_correct'].sum() if df['judge_is_correct'].dtype == bool else df['judge_is_correct'].astype(bool).sum()
            else:
                success_count = 0
            total = len(df)
            acc = success_count / total if total > 0 else 0
            if 'estimated_tokens' in df.columns:
                avg_tokens = df['estimated_tokens'].mean() if len(df) > 0 else 0
            elif 'response' in df.columns:
                token_counts = [estimate_tokens(str(r)) for r in df['response']]
                avg_tokens = sum(token_counts) / len(token_counts) if len(token_counts) > 0 else 0
            else:
                avg_tokens = 0
            original_file = evaluated_file.replace('_evaluated.xlsx', '.xlsx')
            file_path = os.path.basename(os.path.dirname(original_file)) + "/" + os.path.basename(original_file)
            results.append({
                "file": file_path,
                "acc": acc,
                "avg_tokens": avg_tokens,
                "total": total,
                "success": int(success_count)
            })
        except Exception as e:
            print(f"Failed to read evaluated file {evaluated_file}: {e}", flush=True)
            continue
    return results

import argparse

async def main():
    parser = argparse.ArgumentParser(description='GSM8K Evaluation')
    parser.add_argument('--file', type=str, help='Specific file to evaluate')
    parser.add_argument('--limit', type=int, help='Limit number of rows per file')
    args = parser.parse_args()

    if not API_KEY:
        print("Error: DEEPSEEK_API_KEY not found.", flush=True)
        return
    if not os.path.exists(TEMPLATE_FILE):
        print(f"Error: Template file {TEMPLATE_FILE} not found.", flush=True)
        return
    with open(TEMPLATE_FILE, 'r', encoding='utf-8') as f:
        template_content = f.read()

    if args.file:
        target_files = [args.file]
    else:
        search_pattern = os.path.join(GSM8K_RESULT_DIR, '**', 'test_result.xlsx')
        all_files = glob.glob(search_pattern, recursive=True)
        target_files = []
        for f in all_files:
            evaluated_file = f.replace('.xlsx', '_evaluated.xlsx')
            if not os.path.exists(evaluated_file):
                target_files.append(f)
            else:
                print(f"Skipping already evaluated: {f} (exists {os.path.basename(evaluated_file)})", flush=True)

    new_results = []
    if target_files:
        print(f"Found {len(target_files)} files to evaluate.", flush=True)
        for file_path in target_files:
            result = await process_file(file_path, template_content, limit=args.limit)
            if result:
                new_results.append(result)
                print(f"File {result['file']} done: ACC={result['acc']:.2%}, Avg Chars={result['avg_tokens']:.1f}")
    else:
        print("No test_result.xlsx files to evaluate.", flush=True)

    print("\nLoading all evaluated results...", flush=True)
    all_evaluated_results = load_existing_evaluated_results(GSM8K_RESULT_DIR)
    results_dict = {}
    for res in all_evaluated_results:
        results_dict[res['file']] = res
    for res in new_results:
        results_dict[res['file']] = res
    summary_data = sorted(results_dict.values(), key=lambda x: x['file'])

    print("\n" + "="*80)
    print("GSM8K Evaluation Summary (all evaluated)")
    print("="*80)
    print(f"{'File':<50} | {'ACC':<10} | {'Avg Chars':<12} | {'Count':<10}")
    print("-" * 90)
    for res in summary_data:
        print(f"{res['file']:<50} | {res['acc']:.2%}    | {res['avg_tokens']:.1f}         | {res['success']}/{res['total']}")
    print("="*80)
    print(f"Total: {len(summary_data)} files evaluated")

if __name__ == "__main__":
    asyncio.run(main())
