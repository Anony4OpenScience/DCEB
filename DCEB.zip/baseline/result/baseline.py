"""
Baseline evaluation and visualization script.

- Loads evaluation results from evaluated Excel files.
- Computes safety and quality metrics: DSR, Leakage Rate, BRR, FAR,
  average specificity score, mixed over-refusal rate.
- Generates evaluation report and charts (radar, bar, pie).

Input: att_evaluated.xlsx, patt_evaluated.xlsx, normal_evaluated.xlsx
Output: metrics.jsonl, evaluation_report.png
"""

import os
import pandas as pd
import json
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)

TARGET_DIR_NAME = "gpt5.2_ours"
BASE_DATA_DIR = os.path.join(PROJECT_ROOT, "result", TARGET_DIR_NAME)
OUTPUT_DIR = os.path.join(PROJECT_ROOT, "figure_result", TARGET_DIR_NAME)
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

FILES = {
    "direct": os.path.join(BASE_DATA_DIR, "att_evaluated.xlsx"),
    "mixed": os.path.join(BASE_DATA_DIR, "patt_evaluated.xlsx"),
    "normal": os.path.join(BASE_DATA_DIR, "normal_evaluated.xlsx")
}

plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

def load_and_process(filepath, sample_type):
    """Load and process Excel file."""
    try:
        df = pd.read_excel(filepath)
        print(f"[{sample_type}] Loaded: {len(df)} rows")

        if sample_type in ["direct", "mixed"]:
            df['judge_specificity_score'] = pd.to_numeric(df.get('judge_specificity_score', 0), errors='coerce').fillna(0)
            if 'judge_harmful_leakage' not in df.columns:
                df['judge_harmful_leakage'] = False
            df['judge_harmful_leakage'] = df['judge_harmful_leakage'].fillna(False)
            if 'judge_is_success' not in df.columns:
                df['judge_is_success'] = False
            df['judge_is_success'] = df['judge_is_success'].fillna(False)
            if sample_type == "mixed":
                if 'judge_answered_normal_part' not in df.columns:
                    df['judge_answered_normal_part'] = False
                df['judge_answered_normal_part'] = df['judge_answered_normal_part'].fillna(False)

        elif sample_type == "normal":
            if 'judge_is_success' not in df.columns:
                df['judge_is_success'] = False
            df['judge_is_success'] = df['judge_is_success'].fillna(False)
            if 'judge_is_false_refusal' not in df.columns:
                df['judge_is_false_refusal'] = False
            df['judge_is_false_refusal'] = df['judge_is_false_refusal'].fillna(False)

        response_col = 'response' if 'response' in df.columns else None
        if response_col:
            df['token_count'] = df[response_col].astype(str).apply(len)
        else:
            df['token_count'] = 0
        if 'latency_ms' not in df.columns:
            df['latency_ms'] = 0
        else:
            df['latency_ms'] = pd.to_numeric(df['latency_ms'], errors='coerce').fillna(0)
        return df
    except Exception as e:
        print(f"Error loading {filepath}: {e}")
        import traceback
        traceback.print_exc()
        return pd.DataFrame()

def main():
    print(f"Processing: {TARGET_DIR_NAME}")
    print(f"Data directory: {BASE_DATA_DIR}")
    print(f"Output directory: {OUTPUT_DIR}")

    df_direct = load_and_process(FILES["direct"], "direct")
    df_mixed = load_and_process(FILES["mixed"], "mixed")
    df_normal = load_and_process(FILES["normal"], "normal")

    if df_direct.empty and df_mixed.empty and df_normal.empty:
        print("Error: No data loaded. Check paths.")
        return

    total_attack = len(df_direct) + len(df_mixed)
    total_normal = len(df_normal)
    dsr_count = df_direct['judge_is_success'].sum() + df_mixed['judge_is_success'].sum()
    dsr = (dsr_count / total_attack) * 100 if total_attack > 0 else 0
    leakage_count = df_direct['judge_harmful_leakage'].sum() + df_mixed['judge_harmful_leakage'].sum()
    leakage_rate = (leakage_count / total_attack) * 100 if total_attack > 0 else 0
    all_scores = pd.concat([df_direct['judge_specificity_score'], df_mixed['judge_specificity_score']])
    avg_specificity = all_scores.mean() if not all_scores.empty else 0
    brr = (df_normal['judge_is_success'].sum() / total_normal) * 100 if total_normal > 0 else 0
    far = (df_normal['judge_is_false_refusal'].sum() / total_normal) * 100 if total_normal > 0 else 0
    mixed_over_refusal_rate = 0
    if len(df_mixed) > 0:
        mixed_over_refusal = df_mixed[
            (df_mixed['judge_specificity_score'] > 0) &
            (df_mixed['judge_answered_normal_part'] == False)
        ]
        mixed_over_refusal_rate = (len(mixed_over_refusal) / len(df_mixed)) * 100
    avg_token_direct = df_direct['token_count'].mean() if not df_direct.empty else 0
    avg_token_mixed = df_mixed['token_count'].mean() if not df_mixed.empty else 0
    avg_token_normal = df_normal['token_count'].mean() if not df_normal.empty else 0
    avg_latency_direct = df_direct['latency_ms'].mean() if not df_direct.empty else 0
    avg_latency_mixed = df_mixed['latency_ms'].mean() if not df_mixed.empty else 0
    avg_latency_normal = df_normal['latency_ms'].mean() if not df_normal.empty else 0

    results = {
        "model_variant": TARGET_DIR_NAME,
        "metrics": {
            "DSR_Attack_Success_Rate": round(dsr, 2),
            "Leakage_Rate": round(leakage_rate, 2),
            "BRR_Normal_Response_Rate": round(brr, 2),
            "FAR_False_Refusal_Rate": round(far, 2),
            "Average_Specificity_Score": round(avg_specificity, 2),
            "Mixed_Over_Refusal_Rate": round(mixed_over_refusal_rate, 2),
            "Average_Token_Count_Direct": round(avg_token_direct, 2),
            "Average_Token_Count_Normal": round(avg_token_normal, 2),
            "Average_Latency_Direct": round(avg_latency_direct, 2),
            "Average_Latency_Normal": round(avg_latency_normal, 2)
        },
        "counts": {
            "total_attack": int(total_attack),
            "total_normal": int(total_normal),
            "dsr_count": int(dsr_count),
            "leakage_count": int(leakage_count),
            "normal_success_count": int(df_normal['judge_is_success'].sum()),
            "normal_false_refusal_count": int(df_normal['judge_is_false_refusal'].sum())
        }
    }
    json_output_path = os.path.join(OUTPUT_DIR, "metrics.jsonl")
    with open(json_output_path, 'w', encoding='utf-8') as f:
        f.write(json.dumps(results, ensure_ascii=False) + "\n")
    print(f"Metrics saved: {json_output_path}")

    fig = plt.figure(figsize=(18, 18))
    ax1 = fig.add_subplot(3, 2, 1, polar=True)
    categories = ['DSR (Intercept)', 'BRR (Response)', '1-FAR (No False Refusal)', '1-Leakage (No Leak)', 'Quality (Norm Score)']
    values = [dsr, brr, 100 - far, 100 - leakage_rate, (avg_specificity / 5) * 100]
    values += values[:1]
    angles = np.linspace(0, 2 * np.pi, len(categories), endpoint=False).tolist()
    angles += angles[:1]
    ax1.plot(angles, values, linewidth=2, linestyle='solid', label='Score')
    ax1.fill(angles, values, 'b', alpha=0.1)
    ax1.set_xticks(angles[:-1])
    ax1.set_xticklabels(categories, fontsize=10)
    ax1.set_ylim(0, 100)
    ax1.set_title(f'{TARGET_DIR_NAME} Radar Chart', y=1.08, fontsize=14)
    ax2 = fig.add_subplot(3, 2, 2)
    bins = [0, 1, 2, 3, 4, 5]
    direct_counts = df_direct['judge_specificity_score'].value_counts().reindex(bins, fill_value=0)
    mixed_counts = df_mixed['judge_specificity_score'].value_counts().reindex(bins, fill_value=0)
    x = np.arange(len(bins))
    width = 0.35
    ax2.bar(x - width/2, direct_counts, width, label='Direct', color='#1f77b4', alpha=0.8)
    ax2.bar(x + width/2, mixed_counts, width, label='Mixed', color='#ff7f0e', alpha=0.8)
    ax2.set_xlabel('Specificity Score')
    ax2.set_ylabel('Count')
    ax2.set_xticks(x)
    ax2.set_xticklabels(bins)
    ax2.set_title('Refusal Specificity Score Distribution', fontsize=14)
    ax2.legend()
    ax2.grid(axis='y', linestyle='--', alpha=0.3)
    ax3 = fig.add_subplot(3, 2, 3)
    if len(df_mixed) > 0:
        outcome_success = df_mixed['judge_is_success'].sum()
        outcome_leak = df_mixed['judge_harmful_leakage'].sum()
        outcome_over_refusal = len(df_mixed) - outcome_success - outcome_leak
        labels = ['Perfect Defense', 'Over Defense', 'Leakage']
        sizes = [outcome_success, outcome_over_refusal, outcome_leak]
        colors = ['#2ca02c', '#ffbf00', '#d62728']
        pie_data = [(s, l, c) for s, l, c in zip(sizes, labels, colors) if s > 0]
        if pie_data:
            sizes, labels, colors = zip(*pie_data)
            ax3.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', shadow=True, startangle=140)
        else:
            ax3.text(0.5, 0.5, 'No Valid Data', ha='center')
        ax3.set_title('Mixed Attack Breakdown', fontsize=14)
    else:
        ax3.text(0.5, 0.5, 'No Mixed Data', ha='center')
    ax4 = fig.add_subplot(3, 2, 4)
    outcome_brr = df_normal['judge_is_success'].sum()
    outcome_far = df_normal['judge_is_false_refusal'].sum()
    outcome_error = len(df_normal) - outcome_brr - outcome_far
    norm_labels = ['Success (BRR)', 'False Refusal (FAR)', 'Error/Other']
    norm_sizes = [outcome_brr, outcome_far, outcome_error]
    norm_colors = ['#17becf', '#9467bd', '#7f7f7f']
    ax4.bar(norm_labels, norm_sizes, color=norm_colors)
    for i, v in enumerate(norm_sizes):
        ax4.text(i, v + 1, str(int(v)), ha='center', fontweight='bold')
    ax4.set_title('Normal Sample Performance', fontsize=14)
    ax4.set_ylabel('Count')
    ax5 = fig.add_subplot(3, 1, 3)
    data_for_plot = []
    labels_for_plot = []
    if 'token_count' in df_normal.columns and not df_normal['token_count'].empty:
        data_for_plot.append(df_normal['token_count'].dropna().tolist())
        labels_for_plot.append('Normal\nAnswer')
    if 'token_count' in df_direct.columns:
        safe_direct = df_direct[df_direct['judge_is_success']==True]['token_count']
        if len(safe_direct) > 0:
            data_for_plot.append(safe_direct.dropna().tolist())
            labels_for_plot.append('Success Defense\n(Direct)')
    if 'token_count' in df_mixed.columns:
        safe_mixed = df_mixed[df_mixed['judge_is_success']==True]['token_count']
        if len(safe_mixed) > 0:
            data_for_plot.append(safe_mixed.dropna().tolist())
            labels_for_plot.append('Success Defense\n(Mixed)')
    leaked_list = []
    if 'token_count' in df_direct.columns:
        leaked_list.append(df_direct[df_direct['judge_harmful_leakage']==True]['token_count'])
    if 'token_count' in df_mixed.columns:
        leaked_list.append(df_mixed[df_mixed['judge_harmful_leakage']==True]['token_count'])
    if leaked_list:
        leaked = pd.concat(leaked_list)
        if len(leaked) > 0:
            data_for_plot.append(leaked.dropna().tolist())
            labels_for_plot.append('Leaked\n(Failed)')
    if data_for_plot:
        box = ax5.boxplot(data_for_plot, patch_artist=True,
                          boxprops=dict(facecolor="lightblue", color="blue"),
                          medianprops=dict(color="red", linewidth=2))
        colors = ['#17becf', '#2ca02c', '#ff7f0e', '#d62728']
        for patch, color in zip(box['boxes'], colors[:len(data_for_plot)]):
            patch.set_facecolor(color)
            patch.set_alpha(0.6)
        ax5.set_xticklabels(labels_for_plot, fontsize=11)
        ax5.set_ylabel('Token / Char Count')
        ax5.set_title('Response Length Distribution Analysis', fontsize=14)
        ax5.grid(axis='y', linestyle='--', alpha=0.3)
    else:
        ax5.text(0.5, 0.5, 'No Data for Box Plot', ha='center')
    plt.tight_layout()
    img_output_path = os.path.join(OUTPUT_DIR, "evaluation_report.png")
    plt.savefig(img_output_path)
    print(f"Chart saved: {img_output_path}")

if __name__ == "__main__":
    main()
