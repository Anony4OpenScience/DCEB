# Model Deployment Environment (English)

This directory contains scripts and configuration files for deploying and running the LLM API service.

## Directory Structure

- `deploy.py`: Main deployment script (with classifier and PDD prefix enhancement)
- `deploy_raw.py`: Raw model deployment (base model + system prompt only)
- `deploy_filter_*.py`: Various filtered deployment variants
- `deploy_unfilter_*.py`: Unfiltered deployment variants
- `api_requests*.jsonl`: API request audit logs
- `api_server*.log`: Service run logs
- `pdd.txt` / `pdd_en.txt`: PDD (Prompt-Dependent Defense) prefix prompt files
- `prompts.md`: System prompt template

## Requirements

### Hardware
- GPU: At least 2 GPUs (NVIDIA, >= 24GB VRAM recommended)
  - GPU 0: Classification model
  - GPU 1: Generation model
- RAM: >= 32GB recommended

### Software

```bash
Python >= 3.8

# Core dependencies
torch >= 2.0.0
transformers >= 4.30.0
peft >= 0.3.0
fastapi >= 0.100.0
uvicorn >= 0.23.0
pydantic >= 2.0.0
```

### Model Paths

Configure the following paths in the deployment scripts:

```python
BASE_MODEL_DIR = "/path/to/Qwen2.5-7B-Instruct"
ADAPTER_PATH = "/path/to/qlora-adapter"
CLS_MODEL_DIR = "/path/to/classifier"
PDD_PATH = "/path/to/pdd.txt"
```

## Features

### 1. Service Architecture

- **Generation model**: Qwen2.5-7B-Instruct, LoRA fine-tuning supported
- **Classifier**: 6 attack types + normal queries
- **PDD**: Dynamic defense prefix by classification result

### 2. API

#### `/model` endpoint

**Request**:
```json
{
  "text": "User input text",
  "max_new_tokens": 4096
}
```

**Response**:
```json
{
  "code": 200,
  "data": "Model reply"
}
```

### 3. Security

- System prompt with safety rules
- Classifier (labels 1–6)
- PDD prefix by attack type
- Deterministic decoding (temperature=0.0)

### 4. Performance

- Concurrency: `MAX_CONCURRENT` and `WORKERS`
- Timeout: 54 seconds per request
- Logs: `api_server.log` (rotate 10MB), `api_requests.jsonl` (audit)

## Usage

### Start service

```bash
python deploy.py

# Or with uvicorn
uvicorn deploy:app --host 0.0.0.0 --port 8000 --workers 1

MAX_CONCURRENT=4 WORKERS=2 python deploy.py
```

### Test API

```bash
curl -X POST "http://localhost:8000/model" \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello, introduce yourself", "max_new_tokens": 512}'
```

### Logs

```bash
tail -f api_server.log
tail -f api_requests.jsonl | jq
```

## Classifier Labels

1. **Persona/jailbreak**: Inducing AI to adopt an inappropriate persona
2. **Sensitive content**: Illegal, dangerous, explicit content
3. **Goal hijacking**: Changing AI goal or output style
4. **Prompt leakage**: Extracting system prompts
5. **Adversarial inducement**: Rhetorical/counterexample traps
6. **Normal query**

## Notes

1. Set correct model paths and ensure files exist
2. Ensure sufficient GPU VRAM to avoid OOM
3. Default port 8000; change if in use
4. Rotate/clean logs to save disk
5. Tune `MAX_CONCURRENT` and `WORKERS` for your hardware

## Troubleshooting

- **Model load failure**: Check paths and VRAM
- **API timeout**: Check GPU usage, reduce `max_new_tokens`
- **Out of memory**: Lower `MAX_CONCURRENT` and workers or use smaller/quantized model

## Related Files

- `prompts.md`: System prompt template
- `pdd.txt`: PDD prefixes (English)
- `pdd_en.txt`: PDD prefixes (English, alternate)
