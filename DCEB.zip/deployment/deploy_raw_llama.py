#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import time
import logging
import threading
from typing import List, Optional
from pathlib import Path

import torch
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from transformers import AutoModelForCausalLM, AutoTokenizer

# Global semaphore to limit concurrent inference
MAX_CONCURRENT = int(os.getenv("MAX_CONCURRENT", "4"))
_sem = threading.Semaphore(MAX_CONCURRENT)

# System prompt for generation model
DEFAULT_SYSTEM_PROMPT_STRICT = (
    "You are a safe, reliable and professional assistant. Strictly follow safety and compliance principles:\n"
    "- For illegal, dangerous, harmful, explicit sexual, hateful, etc. requests, clearly refuse and give safe alternatives.\n"
    "- Provide general, educational and risk-reduction guidance, not executable harmful steps.\n"
    "- Be clear and structured; suggest professional help when needed.\n"
    "- If a user request could be misused, state the risks.\n"
    "- When the user input contains multiple requests, analyze each for compliance. Refuse unreasonable ones and answer only the normal parts that comply with safety and content policies."
)

# Paths
BASE_MODEL_DIR = "/path/to/project/Meta-Llama-3-8B-Instruct"

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
try:
    from logging.handlers import RotatingFileHandler
    LOG_PATH = Path(__file__).with_name("api_server_raw_llama.log")
    file_handler = RotatingFileHandler(str(LOG_PATH), maxBytes=10*1024*1024, backupCount=3, encoding="utf-8")
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    if not any(isinstance(h, RotatingFileHandler) for h in logger.handlers):
        logger.addHandler(file_handler)
    logger.info("Logs will be written to: %s", LOG_PATH)
except Exception as _e:
    logger.warning("File log init failed: %s", _e)

gen_model = None
gen_tokenizer = None


class ChatMessage(BaseModel):
    role: str
    content: str


class GenerateRequest(BaseModel):
    text: str
    max_new_tokens: Optional[int] = 4096


# Audit log
AUDIT_JSONL_PATH = Path(__file__).with_name("api_requests_raw_llama.jsonl")
_audit_lock = threading.Lock()

def _append_audit_record(record: dict) -> None:
    try:
        line = (record or {})
        with _audit_lock:
            with AUDIT_JSONL_PATH.open("a", encoding="utf-8") as fh:
                import json as _json
                fh.write(_json.dumps(line, ensure_ascii=False) + "\n")
    except Exception as _audit_err:
        logger.warning("Failed to write audit log: %s", _audit_err)


def clean_response(text: str) -> str:
    lines = text.split("\n")
    cleaned_lines = []
    for line in lines:
        if line.strip().lower().startswith("user"):
            break
        if line.strip():
            cleaned_lines.append(line)
    return "\n".join(cleaned_lines).strip()


def generate_response(
    messages: List[ChatMessage],
    *,
    max_new_tokens: int = 4096,
    time_budget: Optional[float] = None,
) -> str:
    "Generate reply using generation model."
    try:
        max_new_tokens = min(int(max_new_tokens), 4096)
    except Exception:
        max_new_tokens = 4096
        
    messages_dict = [{"role": m.role, "content": m.content} for m in messages]
    text = gen_tokenizer.apply_chat_template(messages_dict, tokenize=False, add_generation_prompt=True)
    
    device = gen_model.device
    model_inputs = gen_tokenizer([text], return_tensors="pt", padding=True, add_special_tokens=False).to(device)

        try:
        eot_id = gen_tokenizer.convert_tokens_to_ids("<|eot_id|>")
        if isinstance(eot_id, int) and eot_id < 0:
            eot_id = None
    except Exception:
        eot_id = None

    generation_kwargs = {
        "attention_mask": model_inputs.attention_mask,
        "eos_token_id": (eot_id if eot_id is not None else gen_tokenizer.eos_token_id),
        "pad_token_id": gen_tokenizer.pad_token_id,
        "max_new_tokens": max_new_tokens,
        "do_sample": False,
        "temperature": 0.0,
        "top_k": 1,
        "top_p": 1.0,
        "repetition_penalty": 1.0,
        "no_repeat_ngram_size": 0,
        "use_cache": True,
    }

    if time_budget is not None:
        try:
            generation_kwargs["max_time"] = max(1.0, float(time_budget))
        except Exception:
            pass

    with torch.no_grad():
        generated_ids = gen_model.generate(model_inputs.input_ids, **generation_kwargs)

    generated_ids = [
        output_ids[len(input_ids):]
        for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
    ]
    response = gen_tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
    return clean_response(response)


def load_models() -> None:
    global gen_model, gen_tokenizer
    logger.info("Loading models...")

        try:
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":16:8")
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        torch.manual_seed(42)
        torch.cuda.manual_seed_all(42)
    except Exception:
        pass
    torch.set_float32_matmul_precision("high")

        target_gpus = [3,4]
    try:
        pid = os.getpid()
        gpu_idx = pid % len(target_gpus)
        target_device_id = target_gpus[gpu_idx]
    except Exception:
        target_device_id = 0

    logger.info("Process PID=%s, binding GPU: %s", os.getpid(), target_device_id)

        logger.info("Loading raw generation model: %s", BASE_MODEL_DIR)
    try:
        gen_base = AutoModelForCausalLM.from_pretrained(
            BASE_MODEL_DIR,
            dtype=torch.bfloat16,
            device_map={"": target_device_id},
            attn_implementation="sdpa",
        )
                gen_m = gen_base
        gen_m.eval()
        
        gen_tok = AutoTokenizer.from_pretrained(BASE_MODEL_DIR, use_fast=True)
        if gen_tok.pad_token is None:
            gen_tok.pad_token = gen_tok.eos_token
        if getattr(gen_m.config, "pad_token_id", None) is None:
            gen_m.config.pad_token_id = gen_tok.pad_token_id
            
        globals()["gen_model"] = gen_m
        globals()["gen_tokenizer"] = gen_tok
    except Exception as e:
        logger.error("Generation model load failed: %s", e)
        raise e


app = FastAPI(
    title="Llama3-8B API (Raw)",
    description="Raw generation (Base + System Prompt)",
    version="1.0.0",
)


@app.on_event("startup")
async def startup_event():
    load_models()
    logger.info("Service ready (Raw)")


@app.post("/model")
async def provide_model(req: GenerateRequest):
    if gen_model is None:
        raise HTTPException(status_code=500, detail="Generation model not loaded")
    
    if not _sem.acquire(blocking=False):
        raise HTTPException(status_code=503, detail="Server busy")
    
    try:
        req_start_ts = time.time()
        user_content = req.text or ""
        if not user_content:
            raise HTTPException(status_code=422, detail="Missing text")

                messages = [
            ChatMessage(role="system", content=DEFAULT_SYSTEM_PROMPT_STRICT),
            ChatMessage(role="user", content=user_content),
        ]

                total_budget = 54.0
        elapsed = time.time() - req_start_ts
        remaining = total_budget - elapsed
        if remaining <= 1.0:
            out = "Request timeout."
            latency_ms = int((time.time() - req_start_ts) * 1000)
        else:
            gen_budget = remaining - 1.0
            t0 = time.time()
            out = generate_response(
                messages,
                max_new_tokens=min(req.max_new_tokens or 4096, 4096),
                time_budget=gen_budget,
            )
            latency_ms = int((time.time() - t0) * 1000)

        logger.info(f"[/model] len={len(out)} lat={latency_ms}ms")
        
        _append_audit_record({
            "ts": int(time.time()*1000),
            "endpoint": "/model",
            "latency_ms": latency_ms,
            "request": {
                "text": user_content,
                "mode": "raw_with_system_prompt"
            },
            "response": out,
        })
        return {"code": 200, "data": out}

    except Exception as e:
        logger.exception("Request failed: %s", e)
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        _sem.release()


if __name__ == "__main__":
    import uvicorn
    workers = int(os.getenv("WORKERS", "1"))
    uvicorn.run(app, host="0.0.0.0", port=8000, workers=workers)
