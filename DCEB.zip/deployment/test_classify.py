#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script for classification API.
Reads test data from att.jsonl, calls classify API and records results.
"""
import json
import time
import requests
from pathlib import Path
from typing import List, Dict, Any
from collections import defaultdict

API_URL = "http://localhost:8004/classify"
TEST_DATA_PATH = Path("/path/to/project/lora_data/test/att.jsonl")
OUTPUT_PATH = Path(__file__).with_name("classify_test_results.jsonl")


def load_test_data(file_path: Path, max_samples: int = 1000) -> List[Dict[str, Any]]:
    """Load test data."""
    samples = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            if line_num > max_samples:
                break
            try:
                data = json.loads(line.strip())
                if 'conversations' in data and len(data['conversations']) > 0:
                    user_content = data['conversations'][0].get('content', '')
                    samples.append({
                        'id': line_num,
                        'user_content': user_content
                    })
            except Exception as e:
                print("Parse failed line %s: %s", line_num, e)
    return samples


def classify_text(text: str, timeout: int = 60) -> Dict[str, Any]:
    """Call classification API."""
    try:
        response = requests.post(
            API_URL,
            json={"text": text},
            timeout=timeout
        )
        if response.status_code == 200:
            result = response.json()
            return {
                'success': True,
                'cls_label': result.get('data', {}).get('label', ''),
                'label_name': result.get('data', {}).get('label_name', ''),
                'latency_ms': result.get('data', {}).get('latency_ms', 0),
                'raw_response': result
            }
        else:
            return {
                'success': False,
                'error': "HTTP %s: %s" % (response.status_code, response.text)
            }
    except requests.exceptions.Timeout:
        return {'success': False, 'error': "Request timeout (>%ss)" % timeout}
    except Exception as e:
        return {'success': False, 'error': str(e)}


def test_classification(samples: List[Dict[str, Any]], output_path: Path):
    """Run batch classification test."""
    label_counts = defaultdict(int)
    success_count = 0
    fail_count = 0
    total_latency = 0
    print("=" * 80)
    print("Starting classification API test")
    print("API URL: %s" % API_URL)
    print("Sample count: %s" % len(samples))
    print("=" * 80 + "\n")
    results = []
    for i, sample in enumerate(samples, 1):
        sample_id = sample['id']
        text = sample['user_content']
        if len(text) > 2000:
            text = text[:2000] + "... [truncated]"
        print("[%s/%s] Sample ID=%s, text len=%s" % (i, len(samples), sample_id, len(sample['user_content'])))
        result = classify_text(text)
        result['sample_id'] = sample_id
        result['original_text_length'] = len(sample['user_content'])
        result['timestamp'] = int(time.time())
        if result['success']:
            label = result['cls_label']
            label_name = result['label_name']
            latency = result['latency_ms']
            label_counts[label] += 1
            success_count += 1
            total_latency += latency
            print("  OK label=%s - %s (latency %s ms)" % (label, label_name, latency))
        else:
            fail_count += 1
            print("  FAIL: %s" % result.get('error', 'Unknown error'))
        results.append(result)
        if i % 10 == 0:
            print("\n  Progress: success=%s fail=%s avg_latency=%.2f ms" % (
                success_count, fail_count, total_latency / max(success_count, 1)))
            print()
    with open(output_path, 'w', encoding='utf-8') as f:
        for result in results:
            f.write(json.dumps(result, ensure_ascii=False) + '\n')
    print("\n" + "=" * 80)
    print("Test complete")
    print("=" * 80)
    print("Total: %s" % len(samples))
    print("Success: %s (%.2f%%)" % (success_count, success_count / len(samples) * 100))
    print("Fail: %s (%.2f%%)" % (fail_count, fail_count / len(samples) * 100))
    print("Avg latency: %.2f ms" % (total_latency / max(success_count, 1)))
    print("Label distribution:")
    for label, count in sorted(label_counts.items(), key=lambda x: int(x[0])):
        print("  %s: %s (%.2f%%)" % (label, count, count / len(samples) * 100))
    print("Results saved to: %s" % output_path)


def main():
    print("Loading test data: %s" % TEST_DATA_PATH)
    samples = load_test_data(TEST_DATA_PATH, max_samples=1000)
    print("Loaded %s samples\n" % len(samples))
    test_classification(samples, OUTPUT_PATH)


if __name__ == "__main__":
    main()
