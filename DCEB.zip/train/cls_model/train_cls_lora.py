#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Train classifier model using classification results (e.g. from DeepSeek API).

- Base model: /path/to/project/Qwen2.5-7B-Instruct
- Training data: /path/to/project/cls_model/training_data.jsonl
- Output: /path/to/project/cls_model/cls_lora_output

Task: input attack prompt, output label 1~6 (6 = normal query/request).
"""

import os
import json
import math
import random
from pathlib import Path
from typing import List, Dict, Any, Optional

import torch
from torch.utils.data import Dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)
from peft import LoraConfig, get_peft_model


BASE_MODEL = "/path/to/project/Qwen2.5-7B-Instruct"
DATA_FILE = "/path/to/project/filter_acc/cls_model/training_data.jsonl"
OUTPUT_DIR = "/path/to/project/filter_acc/cls_model/cls_lora_output"

QWEN_END = "<|im_end|>"


def ensure_pad_token(tokenizer: AutoTokenizer) -> None:
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token


def load_jsonl(path: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                continue
    return out


def build_system_prompt() -> str:
    """Build classifier system prompt (aligned with deployment/deepseek_api_filter)."""
    cats = (
        "1. Persona/jailbreak: Inducing AI to adopt an inappropriate persona to bypass safety.\n"
        "2. Sensitive attack: Direct questions about politically sensitive, illegal, dangerous, explicit, hate, porn, violence.\n"
        "3. Goal hijacking: Forcing change of AI goal or output style.\n"
        "4. Prompt leakage: Inducing AI to leak system prompts, internal policy.\n"
        "5. Adversarial inducement: Rhetorical questions, counterexamples, negation to induce unsafe output.\n"
        "6. Normal query or request"
    )
    return (
        "You are an AI safety classifier. Assign the following user input to exactly one category.\n"
        "Categories (choose one only):\n"
        f"{cats}\n\n"
        "Rules: Output a single digit (1-6) only, no other characters, spaces, punctuation or explanation.\n"
        "Text to classify:\n"
    )


def build_prompt_and_labels(
    tokenizer: AutoTokenizer,
    system_text: str,
    user_text: str,
    target_label: str,
    cutoff_len: int,
) -> Dict[str, Any]:
    tokenizer.truncation_side = "left"
    messages = [
        {"role": "system", "content": system_text},
        {"role": "user", "content": user_text},
    ]
    prompt_text = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )
    # Append EOS to label so inference stops after the digit
    label_with_end = target_label + ("" if target_label.endswith(QWEN_END) else QWEN_END)
    full_text = prompt_text + label_with_end

    full = tokenizer(
        full_text,
        truncation=True,
        max_length=cutoff_len,
        padding=False,
        return_tensors=None,
    )
    prompt_tok = tokenizer(
        prompt_text,
        truncation=True,
        max_length=cutoff_len,
        padding=False,
        return_tensors=None,
    )
    input_ids: List[int] = full["input_ids"]
    attention_mask: List[int] = full["attention_mask"]
    prompt_len = len(prompt_tok["input_ids"])
    labels: List[int] = input_ids.copy()
    for i in range(min(prompt_len, len(labels))):
        labels[i] = -100
    return {"input_ids": input_ids, "attention_mask": attention_mask, "labels": labels}


class ClsDataset(Dataset):
    def __init__(
        self,
        tokenizer: AutoTokenizer,
        data_file: str,
        cutoff_len: int,
        seed: int = 42,
        max_samples: Optional[int] = None,
    ) -> None:
        super().__init__()
        self.tokenizer = tokenizer
        self.cutoff_len = cutoff_len
        self.system_prompt = build_system_prompt()

        raw = load_jsonl(data_file)
        random.Random(seed).shuffle(raw)
        records: List[Dict[str, Any]] = []
        skipped = 0
        for obj in raw:
            prompt = obj.get("prompt")
            case = obj.get("case")
            if not isinstance(prompt, str) or not prompt.strip():
                skipped += 1
                continue
            if not isinstance(case, int) or not (1 <= case <= 6):
                skipped += 1
                continue
            item = build_prompt_and_labels(
                tokenizer=self.tokenizer,
                system_text=self.system_prompt,
                user_text=prompt.strip(),
                target_label=str(case),
                cutoff_len=self.cutoff_len,
            )
            records.append(item)
        if max_samples and max_samples > 0:
            records = records[:max_samples]
        self.records = records
        print("Skipped %d samples, training samples: %d" % (skipped, len(self.records)))

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        return self.records[idx]


class DataCollator:
    def __init__(self, tokenizer: AutoTokenizer) -> None:
        self.tokenizer = tokenizer

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        labels_list = [f.pop("labels") for f in features]
        batch = self.tokenizer.pad(features, padding=True, return_tensors="pt")
        max_len = batch["input_ids"].size(1)
        padded_labels = []
        for lab in labels_list:
            if len(lab) < max_len:
                lab = lab + ([-100] * (max_len - len(lab)))
            else:
                lab = lab[:max_len]
            padded_labels.append(torch.tensor(lab, dtype=torch.long))
        batch["labels"] = torch.stack(padded_labels, dim=0)
        return batch


def build_max_memory_map(safety_ratio: float = 0.9) -> Optional[Dict[int, int]]:
    try:
        import pynvml  # type: ignore
        pynvml.nvmlInit()
        vis = os.environ.get("CUDA_VISIBLE_DEVICES")
        if vis:
            count = len([x for x in vis.split(",") if x.strip() != ""])
        else:
            count = pynvml.nvmlDeviceGetCount()
        mem: Dict[int, int] = {}
        for idx in range(count):
            h = pynvml.nvmlDeviceGetHandleByIndex(idx)
            info = pynvml.nvmlDeviceGetMemoryInfo(h)
            mem[idx] = int(info.free * safety_ratio)
        return mem
    except Exception:
        return None


def main():
    os.environ["CUDA_VISIBLE_DEVICES"] = "3,4"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"

    seed = 42
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

    cutoff_len = 4096
    per_device_train_batch_size = 4
    gradient_accumulation_steps = 8
    num_train_epochs = 3
    lr = 2e-4
    output_dir = OUTPUT_DIR
    logs_dir = str(Path(output_dir) / "logs")

    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL, use_fast=True)
    ensure_pad_token(tokenizer)

    max_memory = build_max_memory_map()
    attn_impl = "sdpa"
    try:
        import flash_attn  # type: ignore
        attn_impl = "flash_attention_2"
    except Exception:
        pass
    base = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL,
        device_map="auto",
        torch_dtype=torch.bfloat16 if torch.cuda.is_available() else None,
        low_cpu_mem_usage=True,
        attn_implementation=attn_impl,
    )
    base.gradient_checkpointing_enable()
    try:
        base.config.use_cache = False
    except Exception:
        pass

    lora_config = LoraConfig(
        r=16,
        lora_alpha=16,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj",
        ],
    )
    model = get_peft_model(base, lora_config)

    dataset = ClsDataset(
        tokenizer=tokenizer,
        data_file=DATA_FILE,
        cutoff_len=cutoff_len,
        seed=seed,
    )

    data_collator = DataCollator(tokenizer)

    dataset_size = len(dataset)
    num_batches_per_epoch = math.ceil(dataset_size / per_device_train_batch_size)
    updates_per_epoch = math.ceil(num_batches_per_epoch / gradient_accumulation_steps)
    total_updates = updates_per_epoch * num_train_epochs

    steps_per_epoch = updates_per_epoch
    print("=" * 60)
    print("Total samples: %d" % dataset_size)
    print("Batches per epoch: %d (batch_size=%d)" % (num_batches_per_epoch, per_device_train_batch_size))
    print("Optimizer steps per epoch: %d (grad_accum=%d)" % (updates_per_epoch, gradient_accumulation_steps))
    print("Epochs: %d" % num_train_epochs)
    print("Total optimizer steps: %d" % total_updates)
    print("Save strategy: every %d steps (end of each epoch)" % steps_per_epoch)
    print("Keeping: epoch 2 (step %d) and epoch 3 (step %d) checkpoints" % (steps_per_epoch * 2, steps_per_epoch * 3))
    print("=" * 60)

    training_args = TrainingArguments(
        output_dir=output_dir,
        logging_dir=logs_dir,
        per_device_train_batch_size=per_device_train_batch_size,
        gradient_accumulation_steps=gradient_accumulation_steps,
        learning_rate=lr,
        num_train_epochs=num_train_epochs,
        warmup_ratio=0.03,
        lr_scheduler_type="cosine",
        logging_steps=1,
        logging_first_step=True,
        save_total_limit=2,
        save_strategy="steps",
        save_steps=steps_per_epoch,
        bf16=True if torch.cuda.is_available() else False,
        deepspeed=None,
        dataloader_num_workers=2,
        optim="adamw_torch",
        remove_unused_columns=False,
        max_grad_norm=1.0,
        weight_decay=0.01,
        report_to=["tensorboard"],
        load_best_model_at_end=False,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset,
        tokenizer=tokenizer,
        data_collator=data_collator,
    )

    print("TensorBoard log dir: %s" % logs_dir)
    print("View: tensorboard --logdir %s" % logs_dir)
    print("\n" + "=" * 60)
    print("Starting training...")
    print("=" * 60 + "\n")

    import transformers
    transformers.logging.set_verbosity_info()

    trainer.train()
    trainer.save_model()
    tokenizer.save_pretrained(output_dir)
    print("\n" + "=" * 60)
    print("Classifier training finished.")
    print("=" * 60)


if __name__ == "__main__":
    main()

