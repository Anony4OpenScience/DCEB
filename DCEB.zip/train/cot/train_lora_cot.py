#!/usr/bin/env python3
"""
Qwen2.5-7B-Instruct LoRA Fine-tuning Script (CoT Version)
Features:
- Configurable LoRA rank
- EOS token training (Early Stopping)
- Recursive data finding
- CoT Reasoning support (<think>...</think>)
"""

import os
import json
import glob
import random
import argparse
from typing import List, Dict, Any, Optional

import torch
from torch.utils.data import Dataset

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
    DataCollatorForLanguageModeling,
)
from peft import LoraConfig, get_peft_model


DEFAULT_SYSTEM_PROMPT = (
    "You are a safe, reliable and professional assistant. Strictly follow safety and compliance principles:\n"
    "- For illegal, dangerous, harmful, explicit sexual, hateful, etc. requests, clearly refuse and give safe alternatives.\n"
    "- Provide general, educational and risk-reduction guidance, not executable harmful steps.\n"
    "- Be clear and structured; suggest professional help when needed.\n"
    "- If a user request could be misused, state the risks.\n"
    "- When the user input contains multiple requests, analyze each for compliance. Refuse unreasonable ones and answer only the normal parts that comply with safety and content policies."
)


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def load_jsonl(path: str) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except Exception:
                continue
    return items


def iter_jsonl_glob(pattern: str) -> List[Dict[str, Any]]:
    # Enable recursive globbing
    all_paths = sorted(glob.glob(pattern, recursive=True))
    print(f"Found {len(all_paths)} data files matching pattern: {pattern}")
    for p in all_paths:
        print(f"  - {p}")
    
    data: List[Dict[str, Any]] = []
    for p in all_paths:
        data.extend(load_jsonl(p))
    return data


def ensure_pad_token(tokenizer) -> None:
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token


def build_prompt_and_labels(
    tokenizer: AutoTokenizer,
    messages: List[Dict[str, str]],
    response: str,
    cutoff_len: int,
) -> Dict[str, torch.Tensor]:
    # Supervise only the last assistant turn; keep full context (user/assistant history)
    tokenizer.truncation_side = "left"

    prompt_text = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
    )
    
    full_text = prompt_text + (response or "")
    
    if "<|im_end|>" not in (response or ""):
        full_text = full_text + "<|im_end|>"

    # Tokenize
    full = tokenizer(
        full_text,
        truncation=True,
        max_length=cutoff_len,
        padding=False,
        return_tensors=None,
    )
    prompt_tok = tokenizer(
        prompt_text,
        truncation=True,
        max_length=cutoff_len,
        padding=False,
        return_tensors=None,
    )

    input_ids: List[int] = full["input_ids"]
    attention_mask: List[int] = full["attention_mask"]
    prompt_len = len(prompt_tok["input_ids"])
    labels: List[int] = input_ids.copy()
    for i in range(min(prompt_len, len(labels))):
        labels[i] = -100

    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "labels": labels,
    }


class SFTJsonlDataset(Dataset):
    def __init__(
        self,
        tokenizer: AutoTokenizer,
        data_glob: str,
        cutoff_len: int,
        seed: int,
        max_samples: Optional[int] = None,
    ) -> None:
        super().__init__()
        self.tokenizer = tokenizer
        self.cutoff_len = cutoff_len
        data = iter_jsonl_glob(data_glob)
        print(f"Total samples loaded: {len(data)}")
        random.Random(seed).shuffle(data)
        if max_samples and max_samples > 0:
            data = data[:max_samples]
        self.records = data

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        obj = self.records[idx]
        raw_msgs = obj.get("conversations") or obj.get("messages")
        if not raw_msgs:
            prompt = obj.get("prompt") or obj.get("instruction") or ""
            answer = obj.get("output") or obj.get("response") or obj.get("answer") or ""
            raw_msgs = [
                {"role": "system", "content": DEFAULT_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
                {"role": "assistant", "content": answer},
            ]
        norm_msgs = []
        for m in raw_msgs:
            if not isinstance(m, dict): continue
            role = m.get("role", "user")
            content = m.get("content", "")
            reasoning = m.get("reasoning_content", "")
            
            if content or reasoning:
                norm_msgs.append({
                    "role": role, 
                    "content": str(content),
                    "reasoning_content": str(reasoning) if reasoning else ""
                })
                
        last_ass_idx = -1
        for i in range(len(norm_msgs) - 1, -1, -1):
            if norm_msgs[i]["role"] == "assistant":
                last_ass_idx = i
                break
        
        if last_ass_idx >= 0:
            context = norm_msgs[:last_ass_idx]
            target_msg = norm_msgs[last_ass_idx]
            content_str = target_msg["content"]
            reasoning_str = target_msg.get("reasoning_content", "")
            
            if reasoning_str.strip():
                response = f"<think>\n{reasoning_str.strip()}\n</think>\n{content_str}"
            else:
                response = content_str
        else:
            context = norm_msgs
            response = ""
        if not context or context[0].get("role") != "system":
            context.insert(0, {"role": "system", "content": DEFAULT_SYSTEM_PROMPT})
        clean_context = []
        for m in context:
            clean_context.append({"role": m["role"], "content": m["content"]})

        return build_prompt_and_labels(
            tokenizer=self.tokenizer,
            messages=clean_context,
            response=response,
            cutoff_len=self.cutoff_len,
        )


class SFTDataCollator:
    def __init__(self, tokenizer: AutoTokenizer) -> None:
        self.tokenizer = tokenizer

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        labels_list = [f.pop("labels") for f in features]
        batch = self.tokenizer.pad(
            features,
            padding=True,
            return_tensors="pt",
        )
        max_len = batch["input_ids"].size(1)

        padded_labels = []
        for lab in labels_list:
            if len(lab) < max_len:
                lab = lab + ([-100] * (max_len - len(lab)))
            else:
                lab = lab[:max_len]
            padded_labels.append(torch.tensor(lab, dtype=torch.long))

        batch["labels"] = torch.stack(padded_labels, dim=0)
        return batch


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", default="/path/to/models/Qwen2.5-7B-Instruct")
    parser.add_argument(
        "--data_glob",
        default="/path/to/project/lora_cot_data/train/**/*.jsonl", # Default changed to CoT data path
        help="Data glob pattern (recursive)",
    )
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--deepspeed", default=None)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--cutoff_len", type=int, default=5120)
    parser.add_argument("--per_device_train_batch_size", type=int, default=1)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=16) # Adjusted default
    parser.add_argument("--num_train_epochs", type=int, default=2)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--lora_rank", type=int, default=64, help="LoRA Rank")
    parser.add_argument("--lora_alpha", type=int, default=16)
    
    args = parser.parse_args()

    set_seed(args.seed)

    tokenizer = AutoTokenizer.from_pretrained(args.model_path, use_fast=True)
    ensure_pad_token(tokenizer)

    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        torch_dtype=torch.bfloat16,
        low_cpu_mem_usage=True,
    )

    model.gradient_checkpointing_enable()

    lora_config = LoraConfig(
        r=args.lora_rank,
        lora_alpha=args.lora_alpha, 
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj",
        ],
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    train_dataset = SFTJsonlDataset(
        tokenizer=tokenizer,
        data_glob=args.data_glob,
        cutoff_len=args.cutoff_len,
        seed=args.seed,
    )

    data_collator = SFTDataCollator(tokenizer)

    training_args = TrainingArguments(
        output_dir=args.output_dir,
        per_device_train_batch_size=args.per_device_train_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        learning_rate=args.lr,
        num_train_epochs=args.num_train_epochs,
        warmup_ratio=0.03,
        lr_scheduler_type="cosine",
        logging_steps=10,
        save_strategy="epoch",
        save_total_limit=2,
        bf16=True,
        deepspeed=args.deepspeed,
        dataloader_num_workers=4,
        optim="adamw_torch",
        report_to=[],
        ddp_find_unused_parameters=False,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        tokenizer=tokenizer,
        data_collator=data_collator,
    )

    trainer.train()
    trainer.save_model()
    tokenizer.save_pretrained(args.output_dir)


if __name__ == "__main__":
    main()

